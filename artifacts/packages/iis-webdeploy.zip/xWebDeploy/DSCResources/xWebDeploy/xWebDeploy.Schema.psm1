# Examples of sync verb used with ContentPath and iisApp paramters:
#            -verb:sync -source:package=$SourcePath -dest:contentPath=$Destination       
#            -verb:sync -source:package=$SourcePath -dest:iisApp=$Destination
#

#Install Web Deploy 3.6 
Configuration xInstallWebDeploy {
    param(
        [Parameter(Mandatory = $true)]
        [Validateset("Present","Absent")]
        [String]$Ensure,

        [string] $WebDeployMsi = "C:\setup\webdeploy.msi"
    )    

    Package InstallWebDeployTool {
        Arguments = "ADDLOCAL=ALL /qn /norestart LicenseAccepted='0'"
        Ensure    = "Present"
        Name      = "Microsoft Web Deploy 3.6"
        LogPath   = "$Env:SystemDrive\log.txt"
        Path      = $WebDeployMsi
        ProductId = "6773A61D-755B-4F74-95CC-97920E45E696"
    }  
}

# Composite configuration to install an IIS site from a given package. Note that the package has to be created using webdeploy extension.
Configuration xWebDeploy {
    param(
        [Parameter(Mandatory = $true)]
        [string] $SourcePath,
        [Parameter(Mandatory = $true)]
        [string] $Destination,

        [Parameter(Mandatory = $true)]
        [Validateset("Present","Absent")]
        [String]$Ensure,
        [string] $WebDeployMsi = "C:\setup\webdeploy.msi"
    )      
    Import-DSCResource -Name xWebPackageDeploy
    #Install WebDeploy IIS extension on the machine
    xInstallWebDeploy InstallWebDeployTool {
        Ensure = $Ensure
        WebDeployMsi = $WebDeployMsi
    }

    #Deploy a web package in IIS
    xWebPackageDeploy DeployWebPackage {
        SourcePath = $SourcePath
        Destination = $Destination
        Ensure = $Ensure
    } 
}

Export-ModuleMember -Function xInstallWebDeploy
Export-ModuleMember -Function xWebDeploy
